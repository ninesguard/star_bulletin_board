# star_bulletin_board
Digital bulletin board for George Mason University STAR Lab

Uses HTML, CSS, JavaScript and JQuery to display important information pertaining to the lab.  Also displays weather and twitter feeds.

Now with easy setup screen!

Note: I do not take any credit for anything in the scripts or w-font folder, unless it has my alias in it (ninesguard), or my name (Taylor Nelson)
